import edu.stanford.nlp.ling.CoreLabel;
import edu.stanford.nlp.pipeline.CoreDocument;
import edu.stanford.nlp.pipeline.CoreSentence;
import edu.stanford.nlp.pipeline.StanfordCoreNLP;
import java.util.ArrayList;
import java.util.List;
 
public class SentenceRecognizer {
  public List<String> recognizeSentences(String text) {
    List<String> sentences = new ArrayList<>();
    StanfordCoreNLP stanfordCoreNLP = pipeline.getPipeline();
    CoreDocument coreDocument = new CoreDocument(text);
    stanfordCoreNLP.annotate(coreDocument);
    List<CoreSentence> coreSentences = coreDocument.sentences();
    for (CoreSentence sentence : coreSentences) {
      StringBuilder sentenceText = new StringBuilder();
      for (CoreLabel token : sentence.tokens()) {
        sentenceText.append(token.originalText()).append(" ");
      }
      sentences.add(sentenceText.toString().trim());
    }
    return sentences;
  }
 /*public static void main(String[] args) {
        SentenceRecognizer recognizer = new SentenceRecognizer();
        String text = "Hello! How are you? I hope everything is going well.";
        List<String> sentences = recognizer.recognizeSentences(text);
        for (String sentence : sentences) {
            System.out.println(sentence);
        }
    }*/
}