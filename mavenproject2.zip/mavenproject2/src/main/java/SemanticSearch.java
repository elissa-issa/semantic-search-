import java.util.List;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import javax.naming.directory.SearchResult;
import org.bson.Document;

public class SemanticSearch {
      private final textfile textFile;
    private final pdffile pdfFile;
    private final tokenize tokenizer;
    private final SentenceRecognizer sentenceRecognizer;
    private final synonym synonymSearch;
     private MongoDB mongoDB;
 
    public SemanticSearch() {
        this.textFile = new textfile();
        this.pdfFile = new pdffile();
        this.tokenizer = new tokenize();
        this.sentenceRecognizer = new SentenceRecognizer();
        this.synonymSearch = new synonym();
         this.mongoDB = new MongoDB("SearchDB", "SearchHistory");
    }
 
    public class SearchResult {
        private String fileName;
        private String sentence;
        private int position;
 
        public SearchResult(String fileName, String sentence, int position) {
            this.fileName = fileName;
            this.sentence = sentence;
            this.position = position;
        }
 
        public String getFileName() {
            return fileName;
        }
 
        public String getSentence() {
            return sentence;
        }
 
        public int getPosition() {
            return position;
        }
    }
    

    public List<SearchResult> performSearch(String query, File[] files) throws IOException {
        List<Document> existingResults = mongoDB.readDocuments("query", query);
        if (!existingResults.isEmpty()) {
            return convertDocumentsToSearchResults(existingResults);
        } else {
            List<SearchResult> searchResults = searchFiles(query, files);
            for (SearchResult result : searchResults) {
                Document doc = new Document("query", query)
                    .append("fileName", result.getFileName())
                    .append("sentence", result.getSentence())
                    .append("position", result.getPosition());
                mongoDB.createDocument(doc);
            }
            return searchResults;
        }
    }

    private List<SearchResult> searchFiles(String query, File[] files) throws IOException {
    List<SearchResult> searchResults = new ArrayList<>();
    for (File file : files) {
        String text;
        if (file.getName().toLowerCase().endsWith(".pdf")) {
            text = pdfFile.readDocument(file);
        } else {
            text = textFile.readDocument(file);
        }
        List<String> sentences = sentenceRecognizer.recognizeSentences(text);
        List<String> queryTokens = tokenizer.tokenizeText(query);
        List<List<String>> querySynonyms = new ArrayList<>();
        for (String queryToken : queryTokens) {
            List<String> synonyms = synonymSearch.new Dictionary().getSynonyms(queryToken);
            synonyms.add(queryToken); // Also include the original token
            querySynonyms.add(synonyms);
        }
        for (int i = 0; i < sentences.size(); i++) {
            String sentence = sentences.get(i);
            for (List<String> synonyms : querySynonyms) {
                if (synonyms.stream().anyMatch(synonym -> sentence.toLowerCase().contains(synonym.toLowerCase()))) {
                    SearchResult result = new SearchResult(file.getName(), sentence, i);
                    searchResults.add(result);
                    break;
                }
            }
        }
    }
    return searchResults;
}


   private List<SearchResult> convertDocumentsToSearchResults(List<Document> documents) {
    List<SearchResult> results = new ArrayList<>();
    for (Document doc : documents) {
        SearchResult result = new SearchResult(
            doc.getString("fileName"),
            doc.getString("sentence"),
            doc.getInteger("position", -1)
        );
        results.add(result);
    }
    return results;
}

}
