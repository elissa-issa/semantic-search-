
import java.io.IOException;
import java.util.Scanner;

public class Mavenproject2 {
    public static void main(String[] args) throws IOException {
      Scanner scanner = new Scanner(System.in);
       MongoDB mongoDB = new MongoDB("SearchDB", "SearchHistory");
        int choice;
        do {
            System.out.println("Select an action:");
            System.out.println("1. Search for a query");
            System.out.println("2. Update a query");
            System.out.println("3. Delete a query");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    MongoDB.searchQuery(mongoDB, scanner);
                    break;
                case 2:
                    MongoDB.updateQuery(mongoDB, scanner);
                    break;
                case 3:
                    MongoDB.deleteQuery(mongoDB, scanner);
                    break;
                case 4:
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Please enter a valid option.");
            }
        } while (choice != 4);

        scanner.close();
    }
}
