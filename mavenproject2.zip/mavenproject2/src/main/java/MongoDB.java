import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Updates;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import org.bson.Document;

public class MongoDB {
    private MongoDatabase database;
    private MongoCollection<Document> collection;

    public MongoDB(String databaseName, String collectionName) {
        MongoClient mongoClient = new MongoClient("localhost", 27017);
        this.database = mongoClient.getDatabase(databaseName);
        this.collection = database.getCollection(collectionName);
    }

    public void createDocument(Document document) {
        collection.insertOne(document);
        System.out.println("Document inserted successfully.");
    }
    public List<Document> readDocuments(String queryField, String queryValue) {
        List<Document> results = new ArrayList<>();
        MongoCursor<Document> cursor = collection.find(Filters.eq(queryField, queryValue)).iterator();
        while (cursor.hasNext()) {
            results.add(cursor.next());
        }
        return results;
    }
   public void updateDocument(String queryToUpdate, String newValue) {
    collection.updateMany(Filters.eq("query", queryToUpdate), Updates.set("query", newValue));
    
}
   public void deleteDocument(String queryToDelete) {
    collection.deleteMany(Filters.eq("query", queryToDelete));
}

public static void searchQuery(MongoDB mongoDB, Scanner scanner) throws IOException {
        System.out.print("Enter the query to search for: ");
        String query = scanner.nextLine();
        SemanticSearch semanticSearch = new SemanticSearch();
        File[] files = {
            new File("C:\\Users\\Lenovo\\Desktop\\UA courses\\SEMESTRE 4\\c1\\communication.txt"),
        };
        List<SemanticSearch.SearchResult> searchResults = semanticSearch.performSearch(query, files);
    
        if (searchResults.isEmpty()) {
            System.out.println("No relevant sentences found for: " + query);
        } else {
            System.out.println("Search results for: " + query);
            for (SemanticSearch.SearchResult result : searchResults) {
                System.out.println("File: " + result.getFileName() + ", Sentence: " + result.getSentence() + ", Position: " + result.getPosition());
            }
        }
    }
    public static void updateQuery(MongoDB mongoDB, Scanner scanner) {
        System.out.print("Enter the query to update: ");
        String queryToUpdate = scanner.nextLine();
        System.out.print("Enter the new value for the query: ");
        String newValue = scanner.nextLine();
       List<Document> existingResults = mongoDB.readDocuments("query", queryToUpdate);
        if (!existingResults.isEmpty()) {
        mongoDB.updateDocument( queryToUpdate, newValue);
        System.out.println("Query updated successfully.");
        }
        else
           System.out.println("Query not found"); 
    }

    public static void deleteQuery(MongoDB mongoDB, Scanner scanner) {
        System.out.print("Enter the query to delete: ");
        String queryToDelete = scanner.nextLine();
        List<Document> existingResults = mongoDB.readDocuments("query", queryToDelete);
        if (!existingResults.isEmpty()) {
        mongoDB.deleteDocument( queryToDelete);
        System.out.println("Query deleted successfully.");
        }
        else 
            System.out.println("Query not found");
    }

}
