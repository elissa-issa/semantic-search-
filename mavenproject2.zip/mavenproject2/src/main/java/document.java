import java.io.File;
import java.io.IOException;
 
public interface document {
    abstract String readDocument(File file) throws IOException;
}