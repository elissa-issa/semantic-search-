import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
 
 
import java.io.File;
import java.io.IOException;
 
public class pdffile implements document {
//redefine the function in the interface 
    public String readDocument(File file) throws IOException {
        PDDocument document = PDDocument.load(file);
        PDFTextStripper pdfTextStripper = new PDFTextStripper();
        return pdfTextStripper.getText(document);
    }
}