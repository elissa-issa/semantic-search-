import org.json.JSONArray;
import org.json.JSONObject;
 
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
 
public class synonym {
    private static final String USER_AGENT = "MyApp/1.0 (https://example.com)";
    private static final String ENCODING = "UTF-8";
    private static final Logger LOGGER = Logger.getLogger(synonym.class.getName());
    public class Dictionary {
        public List<String> getSynonyms(String wordToSearch) throws IOException {
            ArrayList<String> synonymsList = new ArrayList<>();
            try {
                String encodedWord = URLEncoder.encode(wordToSearch, ENCODING);
                String url = "https://api.datamuse.com/words?rel_syn=" + encodedWord;
                HttpURLConnection con = (HttpURLConnection) new URL(url).openConnection();
                con.setRequestMethod("GET");
                con.setRequestProperty("User-Agent", USER_AGENT);
                con.setConnectTimeout(5000);  
                con.setReadTimeout(5000);    
                int responseCode = con.getResponseCode();
                if (responseCode != 200) {
                    throw new IOException("Failed to fetch synonyms. HTTP response code: " + responseCode);
                }
                StringBuilder response = new StringBuilder();
                try (BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()))) {
                    String inputLine;
                    while ((inputLine = in.readLine()) != null) {
                        response.append(inputLine);
                    }
                }
                JSONArray jsonArray = new JSONArray(response.toString());
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                    synonymsList.add(jsonObject.getString("word"));
                }
            } catch (UnsupportedEncodingException e) {
                LOGGER.log(Level.SEVERE, "Encoding issue with word: " + wordToSearch, e);
                throw e;
            } catch (IOException e) {
                LOGGER.log(Level.SEVERE, "I/O error while fetching synonyms for: " + wordToSearch, e);
                throw e;
            }
            return synonymsList;
        }
    }
     /*public static void main(String[] args) {
        synonym synonymTool = new synonym();
        Dictionary dictionary = synonymTool.new Dictionary();
        try {
            List<String> synonyms = dictionary.getSynonyms("happy");
            System.out.println("Synonyms for 'happy': " + synonyms);
        } catch (IOException e) {
            System.out.println("Error retrieving synonyms: " + e.getMessage());
        }
    }*/
}
