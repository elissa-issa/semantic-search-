import java.util.Properties;
import edu.stanford.nlp.pipeline.StanfordCoreNLP;

 
public class pipeline {
    private static final Properties properties;
    private static final String propertiesName = "tokenize, ssplit";
    private static StanfordCoreNLP stanfordCoreNLP;
 
    private pipeline() {
    }
    static {
        properties = new Properties();
        properties.setProperty("annotators", propertiesName);
    }
 
    public static StanfordCoreNLP getPipeline() {
        if (stanfordCoreNLP == null) {
            stanfordCoreNLP = new StanfordCoreNLP(properties);
        }
        return stanfordCoreNLP;
    }
}

