import edu.stanford.nlp.ling.CoreLabel;
import edu.stanford.nlp.pipeline.CoreDocument;
import edu.stanford.nlp.pipeline.StanfordCoreNLP;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
 
public class tokenize { 
  public List<String> tokenizeText(String text) {
    Properties props = new Properties();
    props.setProperty("annotators", "tokenize");
    StanfordCoreNLP stanfordCoreNLP = new StanfordCoreNLP(props);
    CoreDocument coreDocument = new CoreDocument(text);
    stanfordCoreNLP.annotate(coreDocument);
 
   List<CoreLabel> coreLabelList = coreDocument.tokens();
    List<String> tokens;
      tokens = new ArrayList<>();
    for (CoreLabel coreLabel : coreLabelList) {
      tokens.add(coreLabel.originalText());
    }
    return tokens;
  }
  /*public static void main(String[] args) {
        tokenize tokenizer = new tokenize();
        String text = "Tokenize this sentence.";
        List<String> tokens = tokenizer.tokenizeText(text);
        System.out.println("Tokens: " + tokens);
    }
*/
}

