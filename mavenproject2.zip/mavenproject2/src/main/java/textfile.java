import java.io.BufferedReader;
 
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
 
 
public class textfile implements document {
    public  String readDocument(File file) throws IOException {
        StringBuilder text = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                text.append(line).append("\n");
            }
        }
        return text.toString();
    }
   
}

